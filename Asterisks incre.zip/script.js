// script.js
const starsContainer = document.getElementById('stars-container');

for (let i = 1; i <= 6; i++) {
    const starLine = document.createElement('div');
    starLine.className = 'star-line';
    starLine.textContent = '*'.repeat(i);
    starsContainer.appendChild(starLine);
}
